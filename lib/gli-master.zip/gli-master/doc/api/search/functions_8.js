var searchData=
[
  ['max_5fface',['max_face',['../a00012.html#aa18daf8e8534d4cefabf3b7dfd43a6f3',1,'gli::texture']]],
  ['max_5flayer',['max_layer',['../a00012.html#af8ae0072dcfb583fcd278650b3f55ec6',1,'gli::texture']]],
  ['max_5flevel',['max_level',['../a00012.html#ae174e356683cee9bf9d3e11df4d6f78a',1,'gli::texture']]]
];
