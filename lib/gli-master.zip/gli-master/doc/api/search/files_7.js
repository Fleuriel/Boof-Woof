var searchData=
[
  ['reduce_2ehpp',['reduce.hpp',['../a00046.html',1,'']]]
];
