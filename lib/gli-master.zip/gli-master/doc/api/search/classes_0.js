var searchData=
[
  ['dx',['dx',['../a00001.html',1,'gli']]]
];
